﻿using System;
using Microsoft.AspNetCore.Mvc;
using Dedup.Common;
using Dedup.Repositories;
using Microsoft.AspNetCore.Http;
using Dedup.ViewModels;
using Dedup.Extensions;
using Microsoft.AspNetCore.Routing;
using System.Net;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authentication;
using RestSharp.Extensions.MonoHttp;

namespace Dedup.Controllers
{
    public class SSOController : Controller
    {
        private IResourcesRepository _resourcesRepository;
        private readonly IAuthTokenRepository _authTokenRepository;

        public SSOController(IResourcesRepository resourcesRepository, IAuthTokenRepository authTokenRepository)
        {
            _resourcesRepository = resourcesRepository;
            _authTokenRepository = authTokenRepository;
        }
 

        /// <summary>
        /// Action: Auth
        /// Description: It is called to re-authorise by app itself if the current session has expired.
        /// If user authorised then redirect to home page else redirect to forbidden page
        /// </summary>
        /// <returns></returns>
        [HttpGet("sso/auth"), Route("sso/auth/{id?}")]
        public async Task<IActionResult> auth(string id = "")
        {
            try
            {
                Console.WriteLine("SSO Controller- Auth");
                //clear all session
                HttpContext.Session.Clear();

                if (string.IsNullOrEmpty(HttpContext.GetClaimValue(ClaimTypes.NameIdentifier)) && string.IsNullOrEmpty(id))
                {
                    Console.WriteLine("The current session has expired");
                    TempData["httpStatusCode"] = HttpStatusCode.Unauthorized;
                    TempData["errorMessage"] = string.Format("The current session has expired. Please try to access the {0} addon from heroku dashboard.", ConfigVars.Instance.herokuAddonId);
                    return RedirectToAction("forbidden", new RouteValueDictionary(new { controller = "home", action = "forbidden" }));
                }
                else
                {
                    if (string.IsNullOrEmpty(id))
                    {
                        //assign resource id
                        id = HttpContext.GetClaimValue(ClaimTypes.NameIdentifier);
                    }

                    //validate account by resource id
                    var resources = await _resourcesRepository.Find(id, true);
                    if (resources == null)
                    {
                        Console.WriteLine("The resource-Id is not matching");
                        TempData["httpStatusCode"] = HttpStatusCode.NotFound;
                        return RedirectToAction("forbidden", new RouteValueDictionary(new { controller = "home", action = "forbidden" }));
                    }

                    //clear all cookie
                    foreach (var cookie in Request.Cookies.Keys)
                    {
                        Response.Cookies.Delete(cookie);
                    }

                    //Clear all sessions
                    HttpContext.Session.Clear();

                    var claims = new List<Claim>();
                    claims.Add(new Claim(ClaimTypes.NameIdentifier, resources.uuid));
                    claims.Add(new Claim(ClaimTypes.Version, resources.plan));
                    if (!string.IsNullOrEmpty(resources.app_name))
                        claims.Add(new Claim(ClaimTypes.Name, resources.app_name));
                    if (!string.IsNullOrEmpty(resources.user_email))
                        claims.Add(new Claim(ClaimTypes.Email, resources.user_email));
                    if (resources.AuthToken != null)
                    {
                        claims.Add(new Claim(Constants.HEROKU_ACCESS_TOKEN, resources.AuthToken.access_token));
                        claims.Add(new Claim(Constants.HEROKU_REFRESH_TOKEN, resources.AuthToken.refresh_token));
                        claims.Add(new Claim(Constants.HEROKU_TOKEN_EXPIREDIN, resources.AuthToken.expires_in.ToString()));
                        if (!string.IsNullOrEmpty(resources.AuthToken.user_id))
                            claims.Add(new Claim(Constants.HEROKU_USERID, resources.AuthToken.user_id));
                    }
                    if (!string.IsNullOrEmpty(resources.private_app_url))
                    {
                        claims.Add(new Claim(ClaimTypes.Uri, resources.private_app_url));
                        if (ConfigVars.Instance.deDupPvtEdition)
                        {
                            //refresh all configs
                            await ConfigVars.Instance.LoadDeDupConfigsByTypeAsync();

                            //set kafka serevr url
                        }
                    }

                    await HttpContext.SignOutAsync(Constants.DEFAULT_AUTH_COOKIE_SCHEME);
                    ClaimsPrincipal principal = new ClaimsPrincipal(new ClaimsIdentity(claims, Constants.DEFAULT_AUTH_COOKIE_SCHEME));
                    await HttpContext.SignInAsync(Constants.DEFAULT_AUTH_COOKIE_SCHEME, principal);
                    //redirect to home page
                    return RedirectToAction("index", "home");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: {0}", ex.Message);
                return new StatusCodeResult(500);
            }
        }
    }
}
﻿

namespace Dedup.ViewModels
{
    public struct AppStack
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}

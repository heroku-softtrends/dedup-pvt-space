﻿

namespace Dedup.ViewModels
{
    public struct AppOwner
    {
        public string email { get; set; }
        public string id { get; set; }
    }
}

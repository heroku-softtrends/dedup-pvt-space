﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dedup.ViewModels
{
    public class CompareSourceColumns
    { 
            public string sourceOne { get; set; }
            public string sourceTwo { get; set; }
    }
}

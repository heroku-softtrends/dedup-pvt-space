﻿
namespace Dedup.ViewModels
{
    public struct AccountIdentityProvider
    {
        public string id { get; set; }
        public AccountOrganization organization { get; set; }
    }
}

﻿

namespace Dedup.ViewModels
{
    public struct AppRegion
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}

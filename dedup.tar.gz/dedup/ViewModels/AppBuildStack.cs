﻿
namespace Dedup.ViewModels
{
    public struct AppBuildStack
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}

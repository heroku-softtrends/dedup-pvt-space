﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dedup.ViewModels
{
    public struct AppTeam
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}

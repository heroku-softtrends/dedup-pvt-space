﻿

namespace Dedup.ViewModels
{
    public struct AppOrganization
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}

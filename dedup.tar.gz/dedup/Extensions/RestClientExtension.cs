﻿using RestSharp;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Dedup.Extensions
{
    public static class RestClientExtension
    {
        public static Task<IRestResponse> RestExecuteAsync(this IRestClient client, IRestRequest request)
        {
            var tcs = new TaskCompletionSource<IRestResponse>();

            client.ExecuteAsync(request, response =>
            {
                tcs.SetResult(response);
            });

            return tcs.Task;
        }
        public static Task<IRestResponse> RestExecuteAsync(this IRestClient client, IRestRequest request, CancellationToken cancellationToken)
        {
            var tcs = new TaskCompletionSource<IRestResponse>();

            var asyncHandle = client.ExecuteAsync(request, response =>
            {
                tcs.SetResult(response);
            });

            using (cancellationToken.Register(() =>
            {
                Console.WriteLine("Request cancelled by parent process");
                asyncHandle.Abort();
            }))
            {

                return tcs.Task;
            }
        }
    }
}
